export const publicPath: string;
